package imc.vn.asn1;

/**
 * @deprecated use BERTags
 */
public interface DERTags
    extends BERTags
{
}
