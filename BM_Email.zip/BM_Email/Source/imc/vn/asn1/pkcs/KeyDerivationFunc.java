package imc.vn.asn1.pkcs;

import imc.vn.asn1.ASN1Encodable;
import imc.vn.asn1.ASN1ObjectIdentifier;
import imc.vn.asn1.ASN1Sequence;
import imc.vn.asn1.x509.AlgorithmIdentifier;

public class KeyDerivationFunc
    extends AlgorithmIdentifier
{
    KeyDerivationFunc(
        ASN1Sequence  seq)
    {
        super(seq);
    }
    
    public KeyDerivationFunc(
        ASN1ObjectIdentifier id,
        ASN1Encodable       params)
    {
        super(id, params);
    }
}
