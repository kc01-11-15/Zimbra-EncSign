package imc.vn.asn1.cryptopro;

import imc.vn.asn1.ASN1EncodableVector;
import imc.vn.asn1.ASN1Object;
import imc.vn.asn1.ASN1ObjectIdentifier;
import imc.vn.asn1.ASN1OctetString;
import imc.vn.asn1.ASN1Primitive;
import imc.vn.asn1.ASN1Sequence;
import imc.vn.asn1.ASN1TaggedObject;
import imc.vn.asn1.DERSequence;

import java.util.Enumeration;


public class GOST28147Parameters
    extends ASN1Object
{
    ASN1OctetString iv;
    ASN1ObjectIdentifier paramSet;

    public static GOST28147Parameters getInstance(
        ASN1TaggedObject obj,
        boolean          explicit)
    {
        return getInstance(ASN1Sequence.getInstance(obj, explicit));
    }

    public static GOST28147Parameters getInstance(
        Object obj)
    {
        if(obj == null || obj instanceof GOST28147Parameters)
        {
            return (GOST28147Parameters)obj;
        }

        if(obj instanceof ASN1Sequence)
        {
            return new GOST28147Parameters((ASN1Sequence)obj);
        }

        throw new IllegalArgumentException("Invalid GOST3410Parameter: " + obj.getClass().getName());
    }

    public GOST28147Parameters(
        ASN1Sequence  seq)
    {
        Enumeration     e = seq.getObjects();

        iv = (ASN1OctetString)e.nextElement();
        paramSet = (ASN1ObjectIdentifier)e.nextElement();
    }

    /**
     * <pre>
     * Gost28147-89-Parameters ::=
     *               SEQUENCE {
     *                       iv                   Gost28147-89-IV,
     *                       encryptionParamSet   OBJECT IDENTIFIER
     *                }
     *
     *   Gost28147-89-IV ::= OCTET STRING (SIZE (8))
     * </pre>
     */
    public ASN1Primitive toASN1Primitive()
    {
        ASN1EncodableVector  v = new ASN1EncodableVector();

        v.add(iv);
        v.add(paramSet);

        return new DERSequence(v);
    }
}
